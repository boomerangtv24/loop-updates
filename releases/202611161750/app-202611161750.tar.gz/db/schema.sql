-- Boomerang Loop: base module schema. Documents and the audit log are append-only.

CREATE TABLE IF NOT EXISTS businesses (
  id          text PRIMARY KEY,
  name        text NOT NULL,
  vat_id      char(9) NOT NULL,
  vat_status  text NOT NULL CHECK (vat_status IN ('licensed', 'exempt')),
  address     jsonb NOT NULL DEFAULT '{}',
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS customers (
  id          bigserial PRIMARY KEY,
  business_id text NOT NULL REFERENCES businesses(id),
  name        text NOT NULL,
  vat_id      text,
  is_licensed_dealer boolean NOT NULL DEFAULT false,
  email       text,
  phone       text,
  address     jsonb NOT NULL DEFAULT '{}',
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS customers_business ON customers (business_id, name);

CREATE TABLE IF NOT EXISTS doc_sequences (
  business_id  text NOT NULL REFERENCES businesses(id),
  type         text NOT NULL,
  start_number integer NOT NULL DEFAULT 1,
  last_number  integer,
  PRIMARY KEY (business_id, type)
);

CREATE TABLE IF NOT EXISTS documents (
  seq          bigserial PRIMARY KEY,           -- insertion order = hash-chain order
  business_id  text NOT NULL REFERENCES businesses(id),
  type         text NOT NULL,
  number       integer NOT NULL,
  date         date NOT NULL,
  customer_id  bigint REFERENCES customers(id),
  doc          jsonb NOT NULL,
  hash         char(64) NOT NULL,
  prev_hash    char(64) NOT NULL,
  issued_at    timestamptz NOT NULL,
  UNIQUE (business_id, type, number)
);
CREATE INDEX IF NOT EXISTS documents_business_date ON documents (business_id, date);

CREATE TABLE IF NOT EXISTS audit_log (
  id          bigserial PRIMARY KEY,
  at          timestamptz NOT NULL,
  business_id text NOT NULL,
  actor       text NOT NULL,
  action      text NOT NULL,
  target      text,
  details     jsonb
);

-- Locked records never change. They can be deleted only by the erasure of a closed account at the end of its
-- legal retention period (src/server/privacy.ts sets loop.purge inside that one transaction).
CREATE OR REPLACE FUNCTION forbid_change() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' AND current_setting('loop.purge', true) = 'on' THEN RETURN OLD; END IF;
  RAISE EXCEPTION 'רשומה זו נעולה ואינה ניתנת לשינוי או למחיקה';
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS documents_append_only ON documents;
DROP TRIGGER IF EXISTS documents_append_only ON documents;
CREATE TRIGGER documents_append_only BEFORE UPDATE OR DELETE ON documents
  FOR EACH ROW EXECUTE FUNCTION forbid_change();
DROP TRIGGER IF EXISTS audit_append_only ON audit_log;
DROP TRIGGER IF EXISTS audit_append_only ON audit_log;
CREATE TRIGGER audit_append_only BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Accounts: a user can belong to several businesses (e.g. an accountant serving clients).
CREATE TABLE IF NOT EXISTS users (
  id            bigserial PRIMARY KEY,
  email         text NOT NULL UNIQUE,
  name          text NOT NULL,
  password_hash text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS memberships (
  user_id     bigint NOT NULL REFERENCES users(id),
  business_id text NOT NULL REFERENCES businesses(id),
  role        text NOT NULL CHECK (role IN ('owner', 'member', 'accountant')),
  PRIMARY KEY (user_id, business_id)
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash  char(64) PRIMARY KEY,           -- sha256 of the cookie value; the raw token is never stored
  user_id     bigint NOT NULL REFERENCES users(id),
  business_id text NOT NULL REFERENCES businesses(id),
  expires_at  timestamptz NOT NULL
);

-- One-time links sent by email: password reset, and confirming a privacy request (export / close account).
-- Only the hash is kept. Deleting a user deletes their links.
CREATE TABLE IF NOT EXISTS auth_tokens (
  token_hash  char(64) PRIMARY KEY,
  user_id     bigint NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  purpose     text NOT NULL CHECK (purpose IN ('reset', 'export', 'delete')),
  thread_id   bigint,
  created_at  timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz NOT NULL,
  used_at     timestamptz
);
CREATE INDEX IF NOT EXISTS auth_tokens_user ON auth_tokens (user_id, purpose, created_at);

-- Support email: every conversation with support@ and privacy@, answered by the AI agent or by a person.
-- business_id ties a conversation to the sender's business, so export and erasure include it.
CREATE TABLE IF NOT EXISTS support_threads (
  id           bigserial PRIMARY KEY,
  email        text NOT NULL,
  name         text NOT NULL DEFAULT '',
  mailbox      text NOT NULL CHECK (mailbox IN ('support', 'privacy')),
  subject      text NOT NULL DEFAULT '',
  status       text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'answered', 'waiting', 'escalated', 'resolved', 'ignored')),
  category     text,
  escalation   text,                          -- why a person is needed (Hebrew)
  summary      text,                          -- one line for the office (Hebrew)
  user_id      bigint REFERENCES users(id) ON DELETE SET NULL,
  business_id  text REFERENCES businesses(id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS support_threads_email ON support_threads (email, updated_at DESC);
CREATE INDEX IF NOT EXISTS support_threads_status ON support_threads (status, updated_at DESC);
CREATE TABLE IF NOT EXISTS support_messages (
  id           bigserial PRIMARY KEY,
  thread_id    bigint NOT NULL REFERENCES support_threads(id) ON DELETE CASCADE,
  direction    text NOT NULL CHECK (direction IN ('in', 'out', 'staff', 'note')),
  author       text NOT NULL,                 -- the sender's address, 'agent', or the staff member's email
  subject      text NOT NULL DEFAULT '',
  body         text NOT NULL,
  message_id   text UNIQUE,                   -- the incoming email's Message-ID, so a retried delivery is stored once
  in_reply_to  text,                          -- for outgoing mail: the customer's Message-ID we answer
  state        text NOT NULL DEFAULT 'done' CHECK (state IN ('new', 'done', 'failed')),
  attempts     int NOT NULL DEFAULT 0,
  claimed_at   timestamptz,                   -- being answered right now (a second worker leaves it alone)
  ai           jsonb,                         -- what the AI suggested and what the rules decided
  at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS support_messages_thread ON support_messages (thread_id, at);
CREATE INDEX IF NOT EXISTS support_messages_new ON support_messages (state, at) WHERE state = 'new';

-- CRM: leads move through a pipeline; activities and tasks hang off a lead or a customer.
CREATE TABLE IF NOT EXISTS leads (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  name         text NOT NULL,
  company      text,
  phone        text,
  email        text,
  source       text,
  stage        text NOT NULL DEFAULT 'new' CHECK (stage IN ('new', 'contacted', 'quote_sent', 'negotiation', 'won', 'lost')),
  hot          boolean NOT NULL DEFAULT false,
  value        bigint NOT NULL DEFAULT 0,          -- expected deal value, agorot before VAT
  customer_id  bigint REFERENCES customers(id),    -- set when the lead becomes a customer
  lost_reason  text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS leads_business_stage ON leads (business_id, stage);

CREATE TABLE IF NOT EXISTS activities (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  lead_id      bigint REFERENCES leads(id),
  customer_id  bigint REFERENCES customers(id),
  kind         text NOT NULL CHECK (kind IN ('note', 'call', 'meeting', 'email', 'whatsapp', 'sms', 'stage')),
  body         text NOT NULL,
  actor        text NOT NULL,
  at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS activities_lead ON activities (lead_id, at DESC);

CREATE TABLE IF NOT EXISTS tasks (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  title        text NOT NULL,
  due          date,
  done_at      timestamptz,
  lead_id      bigint REFERENCES leads(id),
  customer_id  bigint REFERENCES customers(id),
  assignee     text,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tasks_business_open ON tasks (business_id, done_at, due);

-- ERP: suppliers, expenses (input VAT), and a product catalog with stock.
CREATE TABLE IF NOT EXISTS suppliers (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  name         text NOT NULL,
  vat_id       text,
  phone        text,
  email        text,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS expenses (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  supplier_id  bigint REFERENCES suppliers(id),
  date         date NOT NULL,
  doc_number   text,                 -- the supplier's invoice number
  category     text NOT NULL,
  description  text,
  net          bigint NOT NULL,      -- agorot before VAT
  vat          bigint NOT NULL DEFAULT 0,
  vat_deductible_bp integer NOT NULL DEFAULT 10000,  -- share of the VAT that may be offset (e.g. 2/3 for a mixed-use car)
  paid         boolean NOT NULL DEFAULT false,
  voided_at    timestamptz,          -- expenses are never deleted, only voided with a reason
  void_reason  text,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS expenses_business_date ON expenses (business_id, date);

CREATE TABLE IF NOT EXISTS items (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  sku          text NOT NULL,
  name         text NOT NULL,
  unit         text NOT NULL DEFAULT 'יחידה',
  price        bigint NOT NULL DEFAULT 0,   -- sale price, agorot before VAT
  cost         bigint NOT NULL DEFAULT 0,
  track_stock  boolean NOT NULL DEFAULT false,
  vat_exempt   boolean NOT NULL DEFAULT false,
  active       boolean NOT NULL DEFAULT true,
  UNIQUE (business_id, sku)
);

CREATE TABLE IF NOT EXISTS stock_moves (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  item_id      bigint NOT NULL REFERENCES items(id),
  qty          numeric(14,4) NOT NULL,      -- positive in, negative out
  reason       text NOT NULL CHECK (reason IN ('purchase', 'sale', 'credit', 'adjust')),
  ref          text,                        -- e.g. tax_invoice:12
  actor        text NOT NULL,
  at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS stock_moves_item ON stock_moves (item_id);
DROP TRIGGER IF EXISTS stock_moves_append_only ON stock_moves;
DROP TRIGGER IF EXISTS stock_moves_append_only ON stock_moves;
CREATE TRIGGER stock_moves_append_only BEFORE UPDATE OR DELETE ON stock_moves
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Modules and subscription: what each business pays for, and its account state.
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS modules text[] NOT NULL DEFAULT '{core,crm,quotes,erp}';
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS seats integer NOT NULL DEFAULT 1;
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'trial';
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS trial_ends date NOT NULL DEFAULT (current_date + 30);
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS source text;
ALTER TABLE businesses DROP CONSTRAINT IF EXISTS businesses_status_check;
ALTER TABLE businesses ADD CONSTRAINT businesses_status_check CHECK (status IN ('trial', 'active', 'locked'));

-- A business opened by Boomerang (the setup side) gets an invite; the owner picks a password from the link.
CREATE TABLE IF NOT EXISTS invites (
  token_hash   char(64) PRIMARY KEY,          -- sha256 of the link token; the raw token is never stored
  business_id  text NOT NULL REFERENCES businesses(id),
  email        text NOT NULL,
  name         text NOT NULL,
  role         text NOT NULL DEFAULT 'owner',
  created_by   text NOT NULL,
  expires_at   timestamptz NOT NULL,
  used_at      timestamptz
);

-- Warehouse: where each item sits, when to reorder, and its barcode.
ALTER TABLE items ADD COLUMN IF NOT EXISTS location text;
ALTER TABLE items ADD COLUMN IF NOT EXISTS min_qty numeric(14,4) NOT NULL DEFAULT 0;
ALTER TABLE items ADD COLUMN IF NOT EXISTS barcode text;
ALTER TABLE stock_moves ADD COLUMN IF NOT EXISTS location text;
ALTER TABLE stock_moves DROP CONSTRAINT IF EXISTS stock_moves_reason_check;
ALTER TABLE stock_moves ADD CONSTRAINT stock_moves_reason_check
  CHECK (reason IN ('purchase', 'sale', 'credit', 'adjust', 'receive', 'dispatch', 'transfer'));

-- Quote approval: the customer opens a private link, signs with their name and picks how to pay.
-- Documents stay append-only; the approval lives beside the quote.
CREATE TABLE IF NOT EXISTS quote_links (
  token_hash    char(64) PRIMARY KEY,         -- sha256 of the link token; the raw token is never stored
  business_id   text NOT NULL REFERENCES businesses(id),
  quote_number  integer NOT NULL,
  created_by    text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS quote_approvals (
  business_id   text NOT NULL REFERENCES businesses(id),
  quote_number  integer NOT NULL,
  signed_name   text NOT NULL,
  pay_method    text NOT NULL,
  approved_at   timestamptz NOT NULL DEFAULT now(),
  ip            text,
  PRIMARY KEY (business_id, quote_number)
);
DROP TRIGGER IF EXISTS quote_approvals_append_only ON quote_approvals;
DROP TRIGGER IF EXISTS quote_approvals_append_only ON quote_approvals;
CREATE TRIGGER quote_approvals_append_only BEFORE UPDATE OR DELETE ON quote_approvals
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Partners (accountants and others) bring businesses with a referral code and earn a share of their subscription.
CREATE TABLE IF NOT EXISTS partners (
  code          text PRIMARY KEY,                  -- short code in the signup link (?ref=CODE)
  token_hash    char(64) NOT NULL UNIQUE,          -- sha256 of the private dashboard link token
  name          text NOT NULL,
  email         text NOT NULL,
  phone         text,
  kind          text NOT NULL DEFAULT 'accountant',
  commission_bp integer NOT NULL DEFAULT 2000,     -- 2000 = 20%
  created_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS partner_code text REFERENCES partners(code);

-- A business at the end of its trial asks to keep going; Boomerang sends a payment link until the payment provider is connected.
CREATE TABLE IF NOT EXISTS payment_requests (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  monthly      bigint NOT NULL,                    -- agorot before VAT, at the time of the request
  plan         text,
  requested_by text NOT NULL,
  requested_at timestamptz NOT NULL DEFAULT now(),
  handled_at   timestamptz
);

-- Failed sign-ins, kept briefly to slow down password guessing (per email and per address).
CREATE TABLE IF NOT EXISTS login_failures (
  id     bigserial PRIMARY KEY,
  email  text NOT NULL,
  ip     text,
  at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS login_failures_email ON login_failures (email, at);
CREATE INDEX IF NOT EXISTS login_failures_ip ON login_failures (ip, at);

-- Two-step sign-in (part of the core module). Each user picks their own ways in; an owner can require it for the team.
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret text;          -- authenticator app secret, sealed with LOOP_SECRET; null = off
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_pending text;         -- secret shown during setup, until the first code is typed
ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_last_step bigint;     -- last 30-second step used, so a code works once
ALTER TABLE users ADD COLUMN IF NOT EXISTS mfa_phone text;            -- confirmed number for SMS codes; null = off
ALTER TABLE users ADD COLUMN IF NOT EXISTS mfa_email boolean NOT NULL DEFAULT false; -- codes to the sign-in email
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS require_mfa boolean NOT NULL DEFAULT false;
-- Passkeys: Face ID, fingerprint or the device PIN (WebAuthn). Only the public key is kept.
CREATE TABLE IF NOT EXISTS passkeys (
  id            text PRIMARY KEY,               -- credential id, base64url
  user_id       bigint NOT NULL REFERENCES users(id),
  public_key    bytea NOT NULL,
  counter       bigint NOT NULL DEFAULT 0,
  transports    text[] NOT NULL DEFAULT '{}',
  name          text NOT NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_used_at  timestamptz
);
CREATE INDEX IF NOT EXISTS passkeys_user ON passkeys (user_id);
-- Recovery codes for a lost phone: only their hash, each used once.
CREATE TABLE IF NOT EXISTS recovery_codes (
  user_id     bigint NOT NULL REFERENCES users(id),
  code_hash   char(64) NOT NULL,
  used_at     timestamptz,
  PRIMARY KEY (user_id, code_hash)
);
-- Short-lived steps of a sign-in or a setup: the half-done login after the password, a passkey
-- challenge, or an SMS/email code. The cookie holds the raw token; only its hash is here.
CREATE TABLE IF NOT EXISTS auth_challenges (
  token_hash   char(64) PRIMARY KEY,
  purpose      text NOT NULL,                  -- login | passkey-login | passkey-add | phone | email
  user_id      bigint REFERENCES users(id),
  business_id  text REFERENCES businesses(id),
  challenge    text,                           -- WebAuthn challenge
  code_hash    char(64),                       -- SMS / email code
  code_sent_at timestamptz,
  sends        integer NOT NULL DEFAULT 0,
  target       text,                           -- phone number being confirmed
  attempts     integer NOT NULL DEFAULT 0,
  expires_at   timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS auth_challenges_expiry ON auth_challenges (expires_at);

-- Payroll: employees with their form-101 details, and one locked payslip per employee per month.
CREATE TABLE IF NOT EXISTS employees (
  id                  bigserial PRIMARY KEY,
  business_id         text NOT NULL REFERENCES businesses(id),
  name                text NOT NULL,
  id_number           char(9) NOT NULL,
  gender              char(1) NOT NULL CHECK (gender IN ('m', 'f')),
  start_date          date NOT NULL,
  end_date            date,
  role                text,
  email               text,
  phone               text,
  address             text,
  bank                text,
  extra_credit_points numeric(5,2) NOT NULL DEFAULT 0,
  base_salary         bigint NOT NULL,                -- agorot a month, full time
  pension_employee_bp integer NOT NULL DEFAULT 600,
  pension_employer_bp integer NOT NULL DEFAULT 650,
  severance_bp        integer NOT NULL DEFAULT 600,
  pension_fund        text,
  created_at          timestamptz NOT NULL DEFAULT now(),
  UNIQUE (business_id, id_number)
);

ALTER TABLE employees ADD COLUMN IF NOT EXISTS pension_fund text;

CREATE TABLE IF NOT EXISTS payslips (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  employee_id  bigint NOT NULL REFERENCES employees(id),
  month        char(7) NOT NULL,                     -- YYYY-MM
  employee     jsonb NOT NULL,                       -- the employee's details as they were that month
  slip         jsonb NOT NULL,                       -- every amount on the payslip
  issued_at    timestamptz NOT NULL DEFAULT now(),
  issued_by    text NOT NULL,
  UNIQUE (business_id, employee_id, month)
);
DROP TRIGGER IF EXISTS payslips_locked ON payslips;
CREATE TRIGGER payslips_locked BEFORE UPDATE OR DELETE ON payslips
  FOR EACH ROW EXECUTE FUNCTION forbid_change();

-- Send by WhatsApp or email: a private link to one document, payslip or form 106. Only the token's hash is stored.
CREATE TABLE IF NOT EXISTS share_links (
  token_hash   char(64) PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  kind         text NOT NULL CHECK (kind IN ('document', 'payslip', 'form106')),
  ref          text NOT NULL,                 -- document "type:number", payslip id, or "employeeId:year"
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  opened_at    timestamptz
);
-- The employee agreed to get payslips digitally (Wage Protection Law: electronic delivery needs consent).
ALTER TABLE employees ADD COLUMN IF NOT EXISTS digital_consent boolean NOT NULL DEFAULT false;

-- Team messages: short notes between users of the same business, optionally pointing at a page in the app.
CREATE TABLE IF NOT EXISTS messages (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  from_user    bigint NOT NULL REFERENCES users(id),
  to_user      bigint NOT NULL REFERENCES users(id),
  body         text NOT NULL,
  link_href    text,                          -- a path inside the app, e.g. /reports?year=2026
  link_title   text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  read_at      timestamptz
);
CREATE INDEX IF NOT EXISTS messages_inbox ON messages (business_id, to_user, read_at);

-- Bank reconciliation (התאמות בנקים): bank movements, from an uploaded statement or, later, a direct bank feed,
-- each matched to a receipt (money in) or an expense (money out).
CREATE TABLE IF NOT EXISTS bank_imports (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  source       text NOT NULL CHECK (source IN ('file', 'feed', 'demo')),
  file_name    text,
  rows_read    int NOT NULL,
  rows_added   int NOT NULL,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bank_lines (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  import_id    bigint NOT NULL REFERENCES bank_imports(id),
  account      text NOT NULL DEFAULT '',
  date         date NOT NULL,
  description  text NOT NULL,
  reference    text,
  amount       bigint NOT NULL,           -- agorot; money in positive, money out negative
  balance      bigint,
  fingerprint  text NOT NULL,             -- the same movement imported twice is kept once
  match_kind   text CHECK (match_kind IN ('document', 'expense', 'ignored')),
  match_ref    text,                      -- "type:number" for a document, the expense id for an expense
  matched_by   text,
  matched_at   timestamptz,
  UNIQUE (business_id, fingerprint)
);
CREATE INDEX IF NOT EXISTS bank_lines_open ON bank_lines (business_id, match_kind, date);

-- ===== Marketing modules: AI ad studio (ads), automations (flows), creative studio (studio), ad connections (connect) =====

-- One brand kit per business: colors, logo and contact line that every ad uses. Also the studio's target times.
CREATE TABLE IF NOT EXISTS marketing_settings (
  business_id  text PRIMARY KEY REFERENCES businesses(id),
  brand        jsonb NOT NULL DEFAULT '{}',   -- {name, primary, accent, logo (data URL), phone, website}
  sla          jsonb NOT NULL DEFAULT '{}',   -- target hours per studio stage
  hook_token   char(64),                      -- hash of the secret in the incoming-leads web address
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- AI ads. The picture of each size is kept as PNG, made in the browser from the ad's SVG.
CREATE TABLE IF NOT EXISTS ads (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  prompt       text NOT NULL,
  style        text NOT NULL,
  headline     text NOT NULL,
  body         text NOT NULL,
  cta          text NOT NULL,
  link         text,                          -- where the ad's button leads
  image        text,                          -- AI background picture (data URL), if one was made
  ai           text NOT NULL DEFAULT 'none',  -- which AI wrote it: 'claude', 'none'
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ads_business ON ads (business_id, created_at DESC);
-- Made on Boomerang's AI key, before the business added its own: limited and marked "דמו".
ALTER TABLE ads ADD COLUMN IF NOT EXISTS demo boolean NOT NULL DEFAULT false;

CREATE TABLE IF NOT EXISTS ad_images (
  ad_id        bigint NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
  format       text NOT NULL CHECK (format IN ('square', 'story', 'banner')),
  png          bytea NOT NULL,
  PRIMARY KEY (ad_id, format)
);

-- Every time an ad is sent to Meta or Google Ads, with what came back.
CREATE TABLE IF NOT EXISTS ad_pushes (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  ad_id        bigint NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
  provider     text NOT NULL,
  ok           boolean NOT NULL,
  remote_id    text,
  detail       text,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);

-- Connected ad accounts. Tokens are encrypted with LOOP_SECRET before they are stored.
CREATE TABLE IF NOT EXISTS ad_connections (
  business_id  text NOT NULL REFERENCES businesses(id),
  provider     text NOT NULL CHECK (provider IN ('meta', 'google')),
  token        text NOT NULL,                 -- encrypted access token (Meta) or refresh token (Google)
  account_name text,
  settings     jsonb NOT NULL DEFAULT '{}',   -- chosen ad account, page, Google customer id, Search Console site
  connected_by text NOT NULL,
  connected_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, provider)
);

-- Automations and their runs, one run per lead per automation.
CREATE TABLE IF NOT EXISTS flows (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  name         text NOT NULL,
  trigger      jsonb NOT NULL DEFAULT '{}',
  steps        jsonb NOT NULL,
  active_since timestamptz,                   -- leads that arrive after this moment enter the flow; null = paused
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS flow_runs (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  flow_id      bigint NOT NULL REFERENCES flows(id) ON DELETE CASCADE,
  lead_id      bigint NOT NULL REFERENCES leads(id),
  step         int NOT NULL DEFAULT 0,
  next_at      timestamptz NOT NULL DEFAULT now(),
  status       text NOT NULL DEFAULT 'running' CHECK (status IN ('running', 'done', 'stopped')),
  outcome      text,
  link_token   text NOT NULL,                 -- random id in the lead's personal link (/m/...), shows the ad and records the opening
  opened_at    timestamptz,
  log          jsonb NOT NULL DEFAULT '[]',
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (flow_id, lead_id)
);
CREATE INDEX IF NOT EXISTS flow_runs_due ON flow_runs (status, next_at);
CREATE UNIQUE INDEX IF NOT EXISTS flow_runs_token ON flow_runs (link_token);

-- Messages a flow wants to send. Sent by the connected provider, or waiting for one tap on "send".
CREATE TABLE IF NOT EXISTS flow_outbox (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  run_id       bigint NOT NULL REFERENCES flow_runs(id) ON DELETE CASCADE,
  channel      text NOT NULL,
  to_addr      text,
  body         text NOT NULL,
  status       text NOT NULL DEFAULT 'waiting' CHECK (status IN ('waiting', 'sent', 'failed', 'skipped')),
  detail       text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  sent_at      timestamptz,
  sent_by      text
);
CREATE INDEX IF NOT EXISTS flow_outbox_waiting ON flow_outbox (business_id, status);

-- Creative studio jobs and their history.
CREATE TABLE IF NOT EXISTS studio_jobs (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  title        text NOT NULL,
  client       text,
  brief        text NOT NULL DEFAULT '',
  assignee     text,
  stage        text NOT NULL DEFAULT 'brief',
  stage_since  timestamptz NOT NULL DEFAULT now(),
  ad_id        bigint REFERENCES ads(id) ON DELETE SET NULL,
  approval_token char(64),                    -- hash of the client's approval link
  approved_by  text,
  approved_at  timestamptz,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS studio_jobs_business ON studio_jobs (business_id, stage);

CREATE TABLE IF NOT EXISTS studio_events (
  id           bigserial PRIMARY KEY,
  job_id       bigint NOT NULL REFERENCES studio_jobs(id) ON DELETE CASCADE,
  actor        text NOT NULL,
  body         text NOT NULL,
  at           timestamptz NOT NULL DEFAULT now()
);

-- Leads pulled from Meta / Google lead forms carry the platform's id, so the same lead is never added twice.
ALTER TABLE leads ADD COLUMN IF NOT EXISTS external_ref text;
-- Leads brought in from a file: old contacts, so they never start automations.
ALTER TABLE leads ADD COLUMN IF NOT EXISTS imported boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS leads_external_ref ON leads (business_id, external_ref) WHERE external_ref IS NOT NULL;
-- When leads were last pulled from the connected account, and the last error if the pull failed.
ALTER TABLE ad_connections ADD COLUMN IF NOT EXISTS pulled_at timestamptz;
ALTER TABLE ad_connections ADD COLUMN IF NOT EXISTS pull_error text;
ALTER TABLE ad_connections ADD COLUMN IF NOT EXISTS pulled_count int NOT NULL DEFAULT 0;

-- Selling abroad: each business has a billing currency; outside Israel the subscription runs through Paddle.
ALTER TABLE businesses ALTER COLUMN vat_id TYPE varchar(20);
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS currency char(3) NOT NULL DEFAULT 'ILS';
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS paddle_customer_id text;
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS paddle_subscription_id text;
CREATE TABLE IF NOT EXISTS paddle_events (
  event_id     text PRIMARY KEY,           -- Paddle may send an event more than once; each is applied once
  type         text NOT NULL,
  business_id  text REFERENCES businesses(id),
  received_at  timestamptz NOT NULL DEFAULT now()
);

-- ===== Noa: the business's contacts, SMS and email packs, and group sends =====

-- Contacts the business uploaded (Excel, Google, phone). Each one carries where its consent came from.
CREATE TABLE IF NOT EXISTS noa_contacts (
  id             bigserial PRIMARY KEY,
  business_id    text NOT NULL REFERENCES businesses(id),
  name           text NOT NULL DEFAULT '',
  phone          text,                          -- E.164
  email          text,                          -- lower case
  consent        boolean NOT NULL DEFAULT false, -- may receive marketing
  consent_source text NOT NULL DEFAULT 'none',
  consent_at     timestamptz,
  opt_token      text NOT NULL,                 -- random id in the contact's own removal link (/u/...)
  created_by     text NOT NULL,
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS noa_contacts_phone ON noa_contacts (business_id, phone) WHERE phone IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS noa_contacts_email ON noa_contacts (business_id, email) WHERE email IS NOT NULL;
CREATE UNIQUE INDEX IF NOT EXISTS noa_contacts_token ON noa_contacts (opt_token);

-- Numbers and addresses that asked to stop. Kept forever, even if the contact is deleted and uploaded again.
CREATE TABLE IF NOT EXISTS noa_optouts (
  business_id  text NOT NULL REFERENCES businesses(id),
  address      text NOT NULL,
  how          text NOT NULL,                   -- 'link', 'reply', 'manual'
  at           timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, address)
);

-- Credits left, and automatic top-up: when a channel drops below `auto_below`, the chosen pack is ordered.
CREATE TABLE IF NOT EXISTS noa_balance (
  business_id  text PRIMARY KEY REFERENCES businesses(id),
  sms          int NOT NULL DEFAULT 0 CHECK (sms >= 0),
  email        int NOT NULL DEFAULT 0 CHECK (email >= 0),
  auto_sms     text,                            -- pack key, or null for no auto top-up
  auto_email   text,
  auto_below   int NOT NULL DEFAULT 100
);

CREATE TABLE IF NOT EXISTS noa_purchases (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  pack         text NOT NULL,
  channel      text NOT NULL CHECK (channel IN ('sms', 'email')),
  credits      int NOT NULL,
  price        bigint NOT NULL,                 -- minor units of `currency`, before tax
  currency     char(3) NOT NULL,
  status       text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested', 'paid', 'canceled')),
  auto         boolean NOT NULL DEFAULT false,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  paid_at      timestamptz
);
CREATE INDEX IF NOT EXISTS noa_purchases_business ON noa_purchases (business_id, created_at DESC);

-- A group send, and one row per recipient.
CREATE TABLE IF NOT EXISTS noa_sends (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  channel      text NOT NULL CHECK (channel IN ('sms', 'email')),
  kind         text NOT NULL CHECK (kind IN ('marketing', 'service')),
  subject      text,
  body         text NOT NULL,
  recipients   int NOT NULL,
  credits      int NOT NULL,
  send_at      timestamptz NOT NULL,
  status       text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'sending', 'done', 'canceled')),
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS noa_sends_due ON noa_sends (status, send_at);

CREATE TABLE IF NOT EXISTS noa_messages (
  id           bigserial PRIMARY KEY,
  send_id      bigint NOT NULL REFERENCES noa_sends(id) ON DELETE CASCADE,
  business_id  text NOT NULL REFERENCES businesses(id),
  contact_id   bigint REFERENCES noa_contacts(id) ON DELETE SET NULL,
  to_addr      text NOT NULL,
  body         text NOT NULL,
  credits      int NOT NULL,
  status       text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed', 'skipped')),
  detail       text,
  sent_at      timestamptz
);
CREATE INDEX IF NOT EXISTS noa_messages_send ON noa_messages (send_id, status);

-- ===== Booking: a public link where customers pick a service and a free time =====
CREATE TABLE IF NOT EXISTS book_settings (
  business_id  text PRIMARY KEY REFERENCES businesses(id),
  slug         text NOT NULL UNIQUE,            -- the public link: /b/<slug>
  hours        jsonb NOT NULL DEFAULT '[]',     -- [{weekday, from, to}] minutes from midnight, local time
  buffer_min   int NOT NULL DEFAULT 0,
  notice_min   int NOT NULL DEFAULT 120,        -- how soon before the time a customer can still book
  horizon_days int NOT NULL DEFAULT 30,
  remind       boolean NOT NULL DEFAULT true,   -- SMS reminder the day before, from Noa's SMS credits
  updated_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS book_services (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  name         text NOT NULL,
  minutes      int NOT NULL CHECK (minutes BETWEEN 5 AND 600),
  price        bigint,                          -- minor units, shown to the customer; null = not shown
  active       boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS book_appointments (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  service_id   bigint REFERENCES book_services(id) ON DELETE SET NULL,
  service_name text NOT NULL,
  name         text NOT NULL,
  phone        text NOT NULL,                   -- E.164
  email        text,
  note         text,
  start_at     timestamptz NOT NULL,
  end_at       timestamptz NOT NULL,
  status       text NOT NULL DEFAULT 'booked' CHECK (status IN ('booked', 'canceled')),
  source       text NOT NULL DEFAULT 'link',    -- 'link', 'staff', later 'noa-voice', 'noa-whatsapp'
  token        text NOT NULL UNIQUE,            -- the customer's own link to see or cancel (/b/t/<token>)
  reminded_at  timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS book_appointments_time ON book_appointments (business_id, start_at) WHERE status = 'booked';
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS tax_rate_bp int CHECK (tax_rate_bp BETWEEN 0 AND 3000); -- own sales tax rate abroad; null = the country's standard rate

-- Google AI for the ad studio: the business's own Gemini API key (encrypted with LOOP_SECRET, never shown again).
-- Without one, the server's GEMINI_API_KEY is used. Nano Banana draws the picture; Veo turns an ad into a short video.
ALTER TABLE marketing_settings ADD COLUMN IF NOT EXISTS gemini_key text;
CREATE TABLE IF NOT EXISTS ad_videos (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  ad_id        bigint NOT NULL REFERENCES ads(id) ON DELETE CASCADE,
  format       text NOT NULL CHECK (format IN ('story', 'banner')),
  status       text NOT NULL DEFAULT 'working' CHECK (status IN ('working', 'ready', 'failed')),
  operation    text,                          -- Google's long-running operation name while working
  model        text,
  detail       text,
  video        bytea,                         -- MP4 once ready
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  done_at      timestamptz
);
CREATE INDEX IF NOT EXISTS ad_videos_ad ON ad_videos (business_id, ad_id);
CREATE INDEX IF NOT EXISTS ad_videos_working ON ad_videos (status) WHERE status = 'working';

-- One-to-one messages to a lead or customer (call, WhatsApp, SMS, email) are logged as activities, SMS included.
DO $$ BEGIN
  ALTER TABLE activities DROP CONSTRAINT IF EXISTS activities_kind_check;
  ALTER TABLE activities ADD CONSTRAINT activities_kind_check CHECK (kind IN ('note', 'call', 'meeting', 'email', 'whatsapp', 'sms', 'stage'));
END $$;

-- Monthly sales target (agorot before VAT), shown on the dashboard against the month's income.
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS monthly_target bigint CHECK (monthly_target >= 0);

-- Notifications: in the app (bell) and on the phone (web push). One row per person, so each reads their own.
CREATE TABLE IF NOT EXISTS notifications (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  user_id      bigint NOT NULL REFERENCES users(id),
  kind         text NOT NULL,
  title        text NOT NULL,
  body         text NOT NULL DEFAULT '',
  href         text,
  at           timestamptz NOT NULL DEFAULT now(),
  read_at      timestamptz
);
CREATE INDEX IF NOT EXISTS notifications_user ON notifications (user_id, business_id, at DESC);
CREATE TABLE IF NOT EXISTS push_subscriptions (
  endpoint     text PRIMARY KEY,
  user_id      bigint NOT NULL REFERENCES users(id),
  business_id  text NOT NULL REFERENCES businesses(id),
  p256dh       text NOT NULL,
  auth         text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS push_subscriptions_user ON push_subscriptions (user_id, business_id);
-- Server-wide values Loop makes once and keeps (the web push key pair, sealed with LOOP_SECRET).
CREATE TABLE IF NOT EXISTS app_secrets (
  key          text PRIMARY KEY,
  value        text NOT NULL
);
-- The morning summary of tasks due today is sent once a day per business.
CREATE TABLE IF NOT EXISTS notify_state (
  business_id  text PRIMARY KEY REFERENCES businesses(id),
  digest_day   date
);
-- A private calendar link per person: tasks and appointments in Google, iPhone or Outlook calendar.
CREATE TABLE IF NOT EXISTS calendar_feeds (
  business_id  text NOT NULL REFERENCES businesses(id),
  user_id      bigint NOT NULL REFERENCES users(id),
  token_hash   char(64) NOT NULL UNIQUE,
  created_at   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (business_id, user_id)
);

-- Noa's setup form: what the business handed over so Noa can answer for it (see src/core/noa-intake.ts).
CREATE TABLE IF NOT EXISTS noa_intake (
  business_id  text PRIMARY KEY REFERENCES businesses(id),
  answers      jsonb NOT NULL DEFAULT '{}',
  submitted_at timestamptz,                    -- sent to Boomerang to go live; null = draft
  updated_by   text NOT NULL,
  updated_at   timestamptz NOT NULL DEFAULT now()
);

-- GDPR: which Terms / Privacy Policy / DPA version the owner accepted, and account closure (erased 90 days later).
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS terms_version text;
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS terms_accepted_at timestamptz;
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS terms_accepted_by text;
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS closed_at timestamptz;
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS erased_at timestamptz; -- first erasure done, tax records kept
ALTER TABLE businesses ADD COLUMN IF NOT EXISTS closed_by text;

-- Organizations (20+ users) that ask for a custom plan from the public site. Seen by Boomerang in /admin.
CREATE TABLE IF NOT EXISTS sales_inquiries (
  id          bigserial PRIMARY KEY,
  created_at  timestamptz NOT NULL DEFAULT now(),
  name        text NOT NULL,
  company     text NOT NULL,
  email       text NOT NULL,
  phone       text,
  seats       integer,
  country     text,
  message     text,
  handled_at  timestamptz
);

-- ===== Noa answers for the business: website chat, WhatsApp, SMS, phone calls and reminder calls =====
-- The business's Noa numbers (Twilio). A call or message to `number` is answered for `business_id`.
CREATE TABLE IF NOT EXISTS noa_lines (
  number       text PRIMARY KEY,                -- E.164
  business_id  text NOT NULL REFERENCES businesses(id),
  voice        boolean NOT NULL DEFAULT true,   -- answers calls
  messages     boolean NOT NULL DEFAULT true,   -- answers SMS and WhatsApp
  hooked_at    timestamptz,                     -- Twilio's webhooks pointed at Loop
  hook_error   text,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS noa_lines_business ON noa_lines (business_id);

-- One conversation per caller, chat visitor or WhatsApp sender; the turns are what was said.
CREATE TABLE IF NOT EXISTS noa_conversations (
  id           bigserial PRIMARY KEY,
  business_id  text NOT NULL REFERENCES businesses(id),
  channel      text NOT NULL CHECK (channel IN ('chat', 'whatsapp', 'sms', 'voice', 'call')),
  external     text NOT NULL,                   -- phone number, chat session or Twilio call id
  lang         text NOT NULL DEFAULT 'he',
  name         text,
  phone        text,
  summary      text,
  outcome      text,                            -- 'booked', 'message', 'handover', 'confirmed', 'canceled'
  appointment_id bigint REFERENCES book_appointments(id) ON DELETE SET NULL,
  seconds      int NOT NULL DEFAULT 0,          -- call length, for voice minutes
  seen_at      timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS noa_conversations_business ON noa_conversations (business_id, updated_at DESC);
CREATE INDEX IF NOT EXISTS noa_conversations_external ON noa_conversations (business_id, channel, external, updated_at DESC);

CREATE TABLE IF NOT EXISTS noa_turns (
  id              bigserial PRIMARY KEY,
  conversation_id bigint NOT NULL REFERENCES noa_conversations(id) ON DELETE CASCADE,
  role            text NOT NULL CHECK (role IN ('customer', 'noa', 'note')),
  text            text NOT NULL,
  at              timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS noa_turns_conversation ON noa_turns (conversation_id, id);

-- Reminder calls the day before (module `calls`), and the customer's answer.
ALTER TABLE book_appointments ADD COLUMN IF NOT EXISTS called_at timestamptz;
ALTER TABLE book_appointments ADD COLUMN IF NOT EXISTS confirmed_at timestamptz;
ALTER TABLE book_settings ADD COLUMN IF NOT EXISTS remind_call boolean NOT NULL DEFAULT true;

-- Calendar sync: the business's Google or Outlook calendar. Busy times there are not offered for booking,
-- and every Loop booking is written into it. `token` is a sealed OAuth refresh token, or null when the
-- business pasted its calendar's private iCal address (`ics_url`, sealed too) instead.
CREATE TABLE IF NOT EXISTS cal_links (
  business_id  text PRIMARY KEY REFERENCES businesses(id),
  provider     text NOT NULL CHECK (provider IN ('google', 'outlook', 'ics')),
  account      text,
  token        text,
  ics_url      text,
  calendar_id  text NOT NULL DEFAULT 'primary',
  busy         jsonb NOT NULL DEFAULT '[]',     -- cached busy times [{s, e}] ISO
  busy_at      timestamptz,
  error        text,
  created_by   text NOT NULL,
  created_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE book_appointments ADD COLUMN IF NOT EXISTS ext_event text; -- the event id in the linked calendar
