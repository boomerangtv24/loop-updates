// Network-first: the books must always be live, so nothing financial is served from cache.
// Only the app shell assets are cached, and an offline notice is shown when there is no connection.
const CACHE = "loop-v2";
const SHELL = ["/offline.html", "/icon-192.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener("fetch", (e) => {
  if (e.request.method !== "GET") return;
  if (e.request.mode === "navigate") {
    e.respondWith(fetch(e.request).catch(() => caches.match("/offline.html")));
    return;
  }
  const url = new URL(e.request.url);
  if (url.pathname.startsWith("/_next/static/")) {
    e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(e.request, copy));
      return res;
    })));
  }
});

// Phone and desktop notifications: new lead, new booking, approved quote, morning tasks.
self.addEventListener("push", (e) => {
  let m = {};
  try { m = e.data ? e.data.json() : {}; } catch { m = { title: e.data && e.data.text() }; }
  e.waitUntil(self.registration.showNotification(m.title || "בומרנג לופ", {
    body: m.body || "", icon: "/icon-192.png", badge: "/icon-192.png", tag: m.tag, dir: "auto", data: { href: m.href || "/notifications" },
  }));
});

self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const href = (e.notification.data && e.notification.data.href) || "/notifications";
  const url = new URL(href, self.location.origin);
  if (url.origin !== self.location.origin) return;
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((wins) => {
    const w = wins.find((c) => new URL(c.url).origin === url.origin);
    return w ? w.focus().then(() => w.navigate(url.href)) : self.clients.openWindow(url.href);
  }));
});
